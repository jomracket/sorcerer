Turn Word Wrap ON if you're using Notepad.

See also the readme.txt in the docs directory.

This is the Quick Start document.

First, unzip all the files into a directory, e.g. c:\WSORCER.

Cool.

Then double-click on the WSORCER icon.

The emulator should now be running.

From the Util menu, select Load .SNP..., then browse down to the SNP directory and open invaders.snp.

Follow the instructions on the screen, use , to move left and . to move right and the space bar to fire.

==

After you've played a round or two of Space Invaders, go and read the readme.txt that's in the DOCS directory!


Enjoy!
James the Animal Tamer
2002
www.geocities.com/emucompboy

