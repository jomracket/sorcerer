Turn Word Wrap ON if you're using Notepad.

This is a VERY preliminary version, and most features are NOT WORKING, so don't expect much!


Windows Exidy Sorcerer for Windows95/98, by James the Animal Tamer.

HOME PAGE:
==========
www.geocities.com/emucompboy
Home of the Virtual Aquarius

CONTACT:
========
emucompboy@yahoo.com

NOTE to ROM IMAGE COLLECTORS:
=============================
Howdy.  I'd prefer you reference my website, rather than putting my files up for download on your site.  These emulators are works in progress, and I will randomly be updating them.  Now, you wouldn't want to have an inferior version on your website, would you?
	Thanks.

System Requirements:
====================
Fast system, Celeron 400MHz or equivalent recommended
Windows95/98
DirectX
16-bit video card (Windows Sorcerer will work in other modes, but may be slow or not look right)
Sound card compatible with DirectX


Known Bugs
==========
Nothing is working very well, so don't expect much



What works:
=====================
CPU
Character set
Joystick (working, but not configurable at present)
Window size configuration
Insertion/removal of game cartridges (you need to Hard Reset to start the cartridge)
Video (Colors can be configured)
Sound (mostly working)



What does NOT work:
=====================
CP/M
Timers (if any)
Interrupts (if any)
Disk Drive
Other peripherals
Memory (with configuration)
Keyboard (emulated and sensible;  can be configured)
Quicktype (provides a means of loading in BASIC programs from text files)
LPRINT/LLIST (To file.)
BASIC CLOAD 
BASIC CSAVE 
Accurate timing 
Optional loading of other ROM OS


What will NEVER work:
=====================
Modem or other RS-232c interface
Any peripheral I can't analyze
Pokemon (sorry, that's for the GAME BOY)


Still left to be done:
======================
Save WAV files
Drag and drop of supported file types
Pretty much everything!



NOTES:
=====================
1.  Joysticks.  Windows Sorcerer uses DirectX for joystick input.  Windows Sorcerer is tuned for using "joypads."  The joypads I'm using are Microsoft Sidewinder Game Pads.  Now, the Exidy Sorcerer did not come with an official joystick, and the only game I have which uses joypads is Galaxians.  Instead of using the "user group proposed standard" for joysticks, this emulator supports Galaxian which does not follow the standard.  (I'll make it configurable as soon as I get some programs which use some other protocol).

2.  Sound.  Uses DirectSound.  It is mostly working.  Known problems include:  The Directsound and CPU emulation are not perfectly in sync, so there can be static.  Note that if your computer is not running the emulator at a fairly steady 100%, then the sound won't be right and may have problems.  The sound can be VERY LOUD;  in the Sound Configuration box, the default is 50%.  I recommend you don't make it any louder (I am not responsible for damage to your speakers in any case).  Again, the only program I have which uses sound is Galaxians, so the emulator supports the kind of sound output that Galaxians does.


3.  Keyboard.  The keyboard is sort of working, in emulated mode only.  Configuration is not working.

4.  Cassette.  Not working.

5.  Game cartridges.  To use these ROMs, from the emulator's file menu, select Load Game ROM.  Select an appropriate cartridge image (.bin file) to load.  To start the software on the cartridge, then select Hard Reset from the emulators file menu.



Versions:
=========
April 8 2002:
	First version, although it's not really working

Credits
=======
Me (James the Animal Tamer) -- Everything that's not mentioned separately below

Z80Em:		Portable Z80 emulator Copyright (C) Marcel de Kogel 1996,1997
	(I grabbed this from MAME)

ay8910.c	From MAME, credited to Ville Hallik, Michael Cuddy,Tatsuyuki Satoh, Fabrice Frances, Nicola Salmoria.

Microsoft	DirectX, Microsoft Visual C++, Microsoft Development Studio, Windows 95/98.  Thanks, Bill.

ROMs, disks, SNP files:	See those for their respective credits.

I did not dump the ROMs, or create the disks and SNP files.  See these sites, from which I grabbed this material:
http://www.liaquay.demon.co.uk/Sorcerer/
http://www.trailingedge.com/exidy/
http://www.lisp.com.au/~michael/exidy/

